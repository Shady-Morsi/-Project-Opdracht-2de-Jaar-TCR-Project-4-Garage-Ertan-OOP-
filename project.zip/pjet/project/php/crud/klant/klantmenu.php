<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Adam, Juan en Shady">
    <title>Title</title>
    <style>
        .button {
            font-family: "Roboto", sans-serif;
            text-transform: uppercase;
            outline: 0;
            background: #202A44;
            width: 25%;
            border: 0;
            padding: 15px;
            color: #FFFFFF;
            font-size: 14px;
            -webkit-transition: all 0.3 ease;
            transition: all 0.3 ease;
            cursor: pointer;
        }
        .form button:hover,.form button:active,.form button:focus {
            background: #fc8474;
        }
        input {
            width: 25%;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #202A44;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #202A44;
        }
        li a:hover {
            background-color: #202A44;
        }
        .Klantenmenu ,.Leveringmenu {
            display:inline-block;
        }
    </style>
</head>
<body>
<header>
<h1>Garage Ertan</h1>
<img src="bovag.png" style="width:5%">
    <ul>
        <li><a href="mainmenu.php">Menu</a></li>
        <li><a href="../project/design/login.html">Log Uit</a></li>
    </ul>
</header>
Welkom Mr, Ertan<br>
<div class = "Orders"></div>
<h2>Kies een Optie</h2>
<div class  = "klantcreate.php">Create</a></div><br>
<div class  = "klantread.php">Read</a></div><br>
<div class  = "klantupdate.php">Update</a></div><br>
<div class  = "klantdelete.php">Delete</a></div><br>>
<footer>
</footer>
</body>
</html>

<?php
