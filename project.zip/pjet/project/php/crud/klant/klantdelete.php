<?php
require_once('DatabaseConnectie.php');
$id = $_GET['id'];

$res = $database->delete($klantid);
if($res){
    header('location: klant.php');
}else{
    echo "De data is niet verwijderd";
}
?>