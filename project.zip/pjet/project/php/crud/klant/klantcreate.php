<?php
require_once("dbs.php");
require_once ("klant.php");
error_reporting(E_ALL);
ini_set('display_errors', 'On');
echo "Hallo wereld";
$database = new dbs("garageertan_ll", "root", "", "localhost");
$database->Connect();
$result = $database->SQLCommando("SELECT * FROM klant",[]);
$auto = new klant($database);
//var_dump($database);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="" type="text/css">
    <title>Title</title>
</head>
<body>
<main class="autow">
    <div class="hm">
        <a href="">back</a>
    </div>

    <h1>Nieuw klant toevoegen.</h1>
    <br>
    <div class="autow1">

        <form  action="klant.php" method="POST">
        naam.<br> <input type="text" name="naam"> <br/>
        woontplaats.<br>  <input type="text" name="woontplaats"> <br/>
        adres. <br> <input type="text" name="adres"> <br/>
        postcode. <br> <input type="text" name="postcode"> <br/>

            <input type="submit" name='insert'>
        </form>
    </div>
</main>
</body>
</html>
