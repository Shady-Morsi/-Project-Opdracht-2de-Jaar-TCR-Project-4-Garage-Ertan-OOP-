<?php?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="" type="text/css">
    <title>Title</title>
</head>
<body>
<main class="klantw">
    <div class="hm">
        <a href="">back</a>
    </div>

    <h1>klant updaten.</h1>
    <br>
    <div class="klantw1">

        <form  action="klant.php" method="POST">
    klantnaam.<br> <input type="text" name="naam"> <br/>
            klantadres.<br>  <input type="text" name="adres"> <br/>
            klantpostcode. <br> <input type="text" name="postcode"> <br/>
            klantplaats. <br> <input type="text" name="woontplaats"> <br/>

            <input type="submit" name='insert'>
        </form>
    </div>
</main>
</body>
</html>
