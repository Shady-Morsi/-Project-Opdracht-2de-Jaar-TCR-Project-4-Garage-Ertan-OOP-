<?php
include_once "dbs.php";

class klant
{
    public $naam, $adres, $postcode, $woontplaats;
    private $id, $database, $exists;

    function __construct($database)
    {
        $this->database = $database;
        $this->exists = false;
    }

    function insert(){
        error_reporting(E_ALL);
        ini_set('display_errors', 'On');
            $this->database->SQLCommando("INSERT INTO klant (postcode, adres, woonplaats, naam) VALUES (:postcode, :adres, :woontplaats, :naam)", [
            "naam" => $this->naam,
            "woontplaats" => $this->woontplaats,
            "postcode" => $this->postcode,
            "adres" => $this->adres]);
        return "insert succesfull";
    }

    function update()
    {
        if (!$this->exists) {
            return "klant not in database yet";

        }
        $this->database->SQLCommando("UPDATE klant SET postcode = :postcode, adres = :adres, woontplaats = :woontplaats, naam = :naam
    WHERE id = :idplaceholder", [
            "naam" => $this->naam,
            "woontplaats" => $this->woontplaats,
            "postcode" => $this->postcode,
            "adres" => $this->adres,
            "idplaceholder" => $this->id]);
        return "update succesfull";
    }

    function read($id)
    {
        $data =
            $this->database->SQLCommando("SELECT * FROM klant where id = :placeholder", ["placeholder=> $id"]);
        if (count($data) == 0) {
            return "not found";
        }
        $klantdata = $data[0];
        $this->naam = $klantdata["naam"];
        $this->woontplaats = $klantdata["woontplaats"];
        $this->adres = $klantdata["adres"];
        $this->postcode = $klantdata["postcode"];
        $this->id = $id;
        $this->exists = true;
        return "found";
    }

    function delete($id)
    {
        $data =
            $this->database->SQLCommando("DELETE * FROM klant where id = :placeholder", ["placeholder=> $id"]);
        if (count($data) == 0) {
            return "not found";
        }
        $klantdata = $data[0];
        $this->naam = $klantdata["naam"];
        $this->woontplaats = $klantdata["woontplaats"];
        $this->adres = $klantdata["adres"];
        $this->postcode = $klantdata["postcode"];
        $this->id = $id;
        $this->exists = true;
        return "delete succesfull";

    }

}
//test
error_reporting(E_ALL);
ini_set('display_errors', 'On');
$database = new dbs("garageertan_ll", "root", "", "localhost");
$database->Connect();
//$x = new Klant($database);
//$x->adres  ="";
//$x->postcode = "";
//$x->naam = "";
//$x->woontplaats = "";
//$x->insert();
$x= new Klant($database);
$x->adres  ='juan';
$x->postcode = 'juan';
$x->naam = 'juan';
$x->woontplaats = 'juan';
$x->insert();
