<?php
/*
 * CRUD voor de klant
 * Maken, Lezen, Updaten, Deleten
 */
include_once "DatabaseConnectie.php";
class auto{
    public $naam, $autokenteken, $automerk, $autokmstand, $autotype;
    private $klantid, $database, $exists;
    function __construct($database){
        $this->database = $database;
    }
    function Read($ID){
        $data =
            $this->database->SQLCommando("SELECT * FROM autokenteken WHERE id = :placeholder",
                ["placeholder" => $ID]);
        if(count($data) == 0){
            return "Not found";
        }
        $autodata = $data[0];
        $this->autokenteken = $autodata["autokenteken"];
        $this->automerk = $autodata["automerk"];
        $this->autokmstand = $autodata["autokmstand"];
        $this->autotype = $autodata["autotype"];
        $this->ID = $ID;
        return "Found";
    }
}