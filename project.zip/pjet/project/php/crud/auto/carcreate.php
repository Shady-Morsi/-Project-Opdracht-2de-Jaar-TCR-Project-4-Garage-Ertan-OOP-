<?php
require_once("dbs.php");
require_once ("car.php");
error_reporting(E_ALL);
ini_set('display_errors', 'On');
echo "Hallo wereld";
$database = new dbs("garageertan_ll", "root", "", "localhost");
$database->Connect();
$result = $database->SQLCommando("SELECT * FROM klant",[]);
$auto = new auto($database);
//var_dump($database);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="" type="text/css">
    <title>Title</title>
</head>
<body>
<main class="autow">
    <div class="hm">
        <a href="">back</a>
    </div>

    <h1>Nieuw auto toevoegen.</h1>
    <br>
    <div class="autow1">

        <form  action="car.php" method="POST">
        autokenteken.<br> <input type="text" name="autokenteken"> <br/>
        automerk.<br>  <input type="text" name="automerk"> <br/>
        autokmstand. <br> <input type="text" name="autokmstand"> <br/>
        autotype. <br> <input type="text" name="autotype"> <br/>

            <input type="submit" name='insert'>
        </form>
    </div>
</main>
</body>
</html>
