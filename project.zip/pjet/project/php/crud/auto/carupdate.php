<?php?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="" type="text/css">
    <title>Title</title>
</head>
<body>
<main class="autow">
    <div class="hm">
        <a href="">back</a>
    </div>

    <h1>car updaten.</h1>
    <br>
    <div class="autow1">

        <form  action="car.php" method="POST">
        autokenteken.<br> <input type="text" name="autokenteken"> <br/>
        automerk.<br>  <input type="text" name="automerk"> <br/>
        autokmstand. <br> <input type="text" name="autokmstand"> <br/>
        autotype. <br> <input type="text" name="autotype"> <br/>

            <input type="submit" name='insert'>
        </form>
    </div>
</main>
</body>
</html>
