<?php
include_once "dbs.php";

class auto
{
    public $naam, $autokenteken, $automerk, $autokmstand, $autotype;
    private $klantid, $database, $exists;

    function __construct($database)
    {
        $this->database = $database;
        $this->exists = false;
    }

    function insert(){
        error_reporting(E_ALL);
        ini_set('display_errors', 'On');
            $this->database->SQLCommando("INSERT INTO auto (naam, autokenteken, automerk, autokmstand,autotype) VALUES (:naam, :autokenteken, :automerk, :autokmstand, :autotype,)", [
            "naam" => $this->naam,
            "autokenteken" => $this->autokenteken,
            "automerk" => $this->automerk,
            "autokmstand" => $this->autokmstand]);
            "autotype" => $this->autotype]);

        return "insert succesfull";
    }

    function update()
    {
        if (!$this->exists) {
            return "auto not in database yet";

        }
        $this->database->SQLCommando("UPDATE klant SET postcode = :postcode, adres = :adres, woontplaats = :woontplaats, naam = :naam
    WHERE id = :idplaceholder", [
            "naam" => $this->naam,
            "autokenteken" => $this->autokenteken,
            "automerk" => $this->automerk,
            "autokmstand" => $this->autokmstand,
            "autotype" => $this->autotype]);
            "id" => $this->id]);

        return "update succesfull";
    }

    function read($id)
    {
        $data =
            $this->database->SQLCommando("SELECT * FROM auto  where id = :placeholder", ["placeholder=> $id"]);
        if (count($data) == 0) {
            return "not found";
        }
        $autodata = $data[0];
        $this->naam = $autodata["naam"];
        $this->autokenteken = $autodata["autokenteken"];
        $this->automerk = $autodata["automerk"];
        $this->autokmstand = $autodata["postcode"];
        $this->autotype = $autodata["autotype"];
        $this->id = $id;
        $this->exists = true;
        return "found";
    }

    function delete($id)
    {
        $data =
            $this->database->SQLCommando("DELETE * FROM auto where id = :placeholder", ["placeholder=> $id"]);
        if (count($data) == 0) {
            return "not found";
        }
        $autodata = $data[0];
        $this->naam = $autodata["naam"];
        $this->autokenteken = $autodata["autokenteken"];
        $this->automerk = $autodata["automerk"];
        $this->autokmstand = $autodata["autokmstand"];
        $this->autotype = $autodata["autotype"];
        $this->id = $id;
        $this->exists = true;
        return "delete succesfull";

    }

}
//test
error_reporting(E_ALL);
ini_set('display_errors', 'On');
$database = new dbs("garageertan_ll", "root", "", "localhost");
$database->Connect();
//$x = new Auto($database);
//$x->autokenteken  ="";
//$x->automerk = "";
//$x->autokmstand = "";
//$x->autotype = "";
//$x->id();
$x= new Auto($database);
$x->autokenteken  ='juan';
$x->automerk = 'juan';
$x->autokmstand = 'juan';
$x->autotype = 'juan';
$x->insert();
