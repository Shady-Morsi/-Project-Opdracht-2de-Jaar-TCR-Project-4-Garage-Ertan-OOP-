<?php
require_once("dbs.php");
require_once ("logg.php");
error_reporting(E_ALL);
ini_set('display_errors', 'On');
$database = new dbs("garageertan_ll", "root", "", "localhost");
session_start();
$database->Connect();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="" type="text/css">
    <title>Title</title>
</head>
<body>
<main class="klantw"><?php
    $resultt = $database->SQLCommando("SELECT * FROM logg",[]);
    $resultt->login();

    if ($this->resultt) {
        //header('location:klantpage.php');
        return "welkome";
    } else {
        return "nothing";
    } ?>
    <form class="logg"  method="post" action="logg.php">
        <label class="usernaam">usernaam</label><br>
        <input id="usernaam" type="text" name="usernaam"><br>
        <label for="wachtwoord">wachtwoord</label><br>
        <input id="wachtwoord" type="password" name="wachtwoord"><br>
        <input type="submit" name="log" value="login" STYLE=" cursor: pointer;">
        <?php// if(isset($_SESSION['error'])){ ?>
            <div class="alert alert- alert-dismissible fade show" role="alert">
                <strong><?php// echo $_SESSION['error']; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php ?>
    </form>
</main>
</body>
</html>
