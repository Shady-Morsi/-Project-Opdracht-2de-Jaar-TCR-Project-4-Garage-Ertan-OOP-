<?php

include_once ("dbs.php");

class logg
{
public $username, $passWrd;
    private $id, $database;

    function __construct($database)
    {
        $this->database = $database;
    }

function login()
{
    //$this->username = $_POST['usernaam'];
    //$this->passWrd = $_POST['wachtwoord'];
    //$_SESSION['usernaam'] = $this->username;
    $this->database = SQLCommando("SELECT * FROM logini where usernaam=:username and  passw =:passWrd");

}
}

$database = new dbs("garageertan_ll", "root", "", "localhost");
session_start();
$database->Connect();
$ds = new logg($database);
$ds->username  ='juan';
$ds->passWrd = '44448888';
$ds->login();
